package com.example.centroformacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentroformacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentroformacionApplication.class, args);
	}

}
