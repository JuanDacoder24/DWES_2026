package com.example.centroformacion.entity;

public enum Especialidad {

    IMFORMATICA, COMERCIO, FINANZAS

}
