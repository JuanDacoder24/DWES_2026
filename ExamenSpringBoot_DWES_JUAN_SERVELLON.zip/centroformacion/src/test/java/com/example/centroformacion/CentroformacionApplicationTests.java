package com.example.centroformacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentroformacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
